const express = require('express')
const expressHandlebars = require('express-handlebars')
const proxy = require('express-http-proxy')
const msal = require('@azure/msal-node')
const fetch = require('node-fetch')
const fs = require('fs')
const fsp = require('fs').promises
const streamifier = require('streamifier')
const Inkscape = require('inkscape')
const  { v4: uuidv4 } = require('uuid')
const { exec } = require("child_process")
const { pathToFileURL } = require('url')
const bodyParser = require('body-parser')
const gremlin = require('gremlin');

/*
    Worldline sips
*/

// First, create a client for the desired environment using your merchant ID, 
// key version & secret key:

const { Environment, PaypageClient } = require('@worldline/sips-payment-sdk');
const paypageClient = new PaypageClient(
  Environment.SIMU,
  '002001000000001',
  1, // This shouldn't be hardcoded here...
  '002001000000001_KEY1'); // ...and neither should this.

// Then set up const to initialize a session on the SIPS server:

const { PaymentRequest, Currency, OrderChannel, PaymentMeanBrand, RedirectionStatusCode } = require('@worldline/sips-payment-sdk');
const { response } = require('express');

/*
    Set Up Express
*/

const app = express()
app.use(express.static(__dirname + '/public'))
app.use(express.static(__dirname + '/out'))
app.engine('handlebars', expressHandlebars({
    defaultlayout: 'main',
}))

app.set('view engine', 'handlebars')

app.use(bodyParser.urlencoded({ extended:true }))


const THIS_SERVER = "http://localhost:3000"

const THIS_NGROK_DOMAIN = "https://a-x-o-solutions.eu.ngrok.io"

const port = process.env.PORT || 3000
app.listen(port, () => console.log(
    'nodeserver started on http://localhost:${port}; '+
    'press Ctrl-C to terminate'
))


/*
    Make a payment
*/

app.get('/paymentGW/makepayment', (re, res) => {
    const paymentRequest = new PaymentRequest();
    paymentRequest.amount = re.query.amount;
    let returnToSalesforce = re.query.returnToSalesforce;
    paymentRequest.currencyCode = Currency.EUR;
    paymentRequest.orderChannel = OrderChannel.INTERNET;
    if (returnToSalesforce == "yes") {
        paymentRequest.normalReturnUrl = THIS_NGROK_DOMAIN +  '/paymentGW/paymentreturnforsf'
    } else {
        paymentRequest.normalReturnUrl = THIS_NGROK_DOMAIN + '/paymentGW/paymentreturnurlman';
    }
    paymentRequest.automaticResponseUrl = THIS_NGROK_DOMAIN + '/paymentGW/paymentreturnurlauto';
    paymentRequest.transactionReference = Math.random().toString(36).substring(7);
    paypageClient.initializePayment(paymentRequest)
    .then((initializationResponse) => {
        console.log('\n $$$ !! initializationResponse \n', JSON.stringify(initializationResponse) );            
        if (initializationResponse.redirectionStatusCode !== RedirectionStatusCode.TRANSACTION_INITIALIZED) {
            // error
            console.log('\n $$$ !! RedirectionStatusCode \n', initializationResponse.redirectionStatusCode );            
        } else {
            let redirectionUrl = initializationResponse.redirectionUrl
            let redirectionVersion = initializationResponse.redirectionVersion
            let redirectionData = initializationResponse.redirectionData
            let seal = initializationResponse.seal;
            res.render('viewPaymentPage', {redirectionUrl:redirectionUrl, redirectionVersion:redirectionVersion,redirectionData:redirectionData, seal:seal})
        }    
    })
})


app.get('/paymentGW/paymentreturnurlman', (re, res) => {
    // this one is for test only
    // should have a look at what is actually returned
    let paymentStatus="test";
    res.render('viewPaymentStatusPage', {paymentStatus:paymentStatus});
})


app.post('/paymentGW/paymentreturnurlman', (re, res) => {
    // should have a look at what is actually returned
    console.log('\n $$$ !! paymentreturnurlMAN re.query \n', re.query);            
    console.log('\n $$$ !! paymentreturnurlMAN re.body \n', re.body);            
    let paymentStatus=re.body.Data;
    res.render('viewPaymentStatusPage', {paymentStatus:paymentStatus});
})

app.post('/paymentGW/paymentreturnforsf', (re, res) => {
    // should have a look at what is actually returned
    console.log('\n $$$ !! paymentreturnurlMAN (sf) re.query \n', re.query);            
    console.log('\n $$$ !! paymentreturnurlMAN (sf) re.body \n', re.body);            
    let paymentStatus=re.body.Data;
    res.render('viewPaymentStatusPage', {paymentStatus:paymentStatus});
})


app.post('/paymentGW/paymentreturnurlauto', (re, res) => {
    console.log('\n $$$ !! paymentreturnurlAUTO re.query \n', re.query);            
    console.log('\n $$$ !! paymentreturnurlAUTO re.body \n', re.body);            
})

