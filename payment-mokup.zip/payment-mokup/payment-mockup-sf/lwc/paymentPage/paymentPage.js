import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getCONFIG_Payment from '@salesforce/apex/BR_Config_Payment.getCONFIG_Payment';

export default class PaymentPage extends LightningElement {

    amount = 0;
    amountInCents = 0;
    paymentFrameUrl = "";
    isWarningVisible = true;
    isMakePaymentVisible = true;
    isPaymentPageVisible = false;
    paymentData = "";

    toastTitle = "Payment";
    toastVariant = "info";
    toastMessage = "Payment status is undefined";

    
    // must be declared in Setup > CSP Trusted Sites

    PAYMENT_URL="";

    connectedCallback() {
        console.log('\n $$$ !! in connectedCallback \n Version=', "0008");
        this.getPaymentUrl(); // initialize PAYMENT_URL

        /*
            Event Listener for handling communication from the iFrame
            Uses EventTarget = window
            In the iframe (viewPaymentStatusPage.handlebars returned by nodeserver.js)
                const message = JSON.stringify({
                    channel: 'paymentFrame',
                    paymentFramepaymentData: document.getElementById("paymentStatus").innerHTML
                })
                window.parent.postMessage(message, '*');
        */
        window.addEventListener('message', (evt) => {
            console.log('\n $$$ !! event received in parent \n')
            const data = JSON.parse(evt.data)
            const channel = data.channel;
            if (channel == 'paymentFrame') {
                this.paymentData = data.paymentData
                this.isPaymentPageVisible = false;
                this.isMakePaymentVisible = true;
                this.amount = 0;
                // assumes all OK but paymentData should be processed
                this.toastVariant = "success";
                this.toastMessage = "Payment completed";
                this.showToast();
                console.log('\n $$$ !! parent received message for paymentFrame: \n', paymentData);
            } else {
                // do nothing
            }
        })
    }

    renderedCallback(){
        return;
    }
    
    handleAmountChange(e) {
        this.amount = e.detail.value;
    }

    handleClick(e) {
        // send to external ...;
        this.amountInCents = Math.round(Number(this.amount)*100);
        if (this.amountInCents == 0) {
            this.toastVariant = "info";
            this.toastMessage = "Amount cannot be zero";
            this.showToast();
            return;
        }
        console.log('\n $$$ !! this.amountInCents : \n', this.amountInCents);
        let payURL = this.PAYMENT_URL+"/paymentGW/makepayment/?amount="+this.amountInCents.toString()+"&returnToSalesforce=yes";
        console.log('\n $$$ !! payURL: \n',payURL);
        this.paymentFrameUrl = payURL;  
        this.isWarningVisible = false;
        this.isMakePaymentVisible = false;
        this.isPaymentPageVisible = true;
    }

    handleCloseWarning(e){
        this.isWarningVisible = false;
    }
    
   
    showToast() {
        console.log('\n $$$ !! in showToast \n')
        const event = new ShowToastEvent({
            title: this.toastTitle,
            message: this.toastMessage,
            variant: this.toastVariant
        });
        this.dispatchEvent(event);
    }

    getPaymentUrl(){
        // @AuraEnabled returns a promise
        getCONFIG_Payment()
        .then( r => {this.PAYMENT_URL = r})
    }

}